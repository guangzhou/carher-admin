@echo off
chcp 65001 >nul
call "%~dp0cursor_team_setup.cmd" --repair
echo.
pause
