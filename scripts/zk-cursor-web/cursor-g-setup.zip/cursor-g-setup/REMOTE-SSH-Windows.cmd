@echo off
chcp 65001 >nul
echo 让「Cursor 连远程服务器」的窗口里也能用 cr-g 的模型。
echo.
call "%~dp0cursor_remote_ssh.cmd"
echo.
set /p HOSTNAME_IN=要配哪台?(照着上面的名字填,或 用户名@IP;直接回车=退出):
if "%HOSTNAME_IN%"=="" (
  echo 已退出,什么都没动。
  pause
  exit /b 0
)
echo.
echo ===== 先预演一遍,只显示要往 ssh 配置里加什么,不落盘 =====
call "%~dp0cursor_remote_ssh.cmd" --host "%HOSTNAME_IN%"
echo.
set /p ans=确认执行?输入 yes 回车(其它任何输入=取消):
if /i "%ans%"=="yes" (
  call "%~dp0cursor_remote_ssh.cmd" --host "%HOSTNAME_IN%" --apply
) else (
  echo 已取消,什么都没动。
)
echo.
pause
