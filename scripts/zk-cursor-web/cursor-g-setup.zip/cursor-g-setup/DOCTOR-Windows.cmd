@echo off
chcp 65001 >nul
echo 自检（只读，不会改任何东西）。把下面整屏发给管理员即可。
echo.
call "%~dp0cursor_team_setup.cmd" --doctor
echo.
pause
