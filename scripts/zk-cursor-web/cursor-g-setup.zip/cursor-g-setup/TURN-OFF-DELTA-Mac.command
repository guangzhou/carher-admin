#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "把 Cursor 退回「直连公网」——不再经过本机小代理。"
echo "（Cursor 必须先完全退出：Cmd+Q）"
sh "$DIR/cursor_team_setup.sh" --apply --no-zk-delta --zk-delta-only
echo ""
printf "按回车键关闭本窗口…"; read _
