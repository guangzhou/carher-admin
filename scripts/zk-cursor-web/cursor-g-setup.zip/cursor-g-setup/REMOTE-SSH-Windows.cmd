@echo off
setlocal
rem All prompts and Chinese text live in cursor_remote_ssh.js (--wizard).
rem This file must stay pure ASCII + CRLF and never switch code page: cmd re-reads .cmd files by byte
rem offset, and non-ASCII lines / LF-only endings shred the following lines (10-13, colleague).
call "%~dp0cursor_remote_ssh.cmd" --wizard
echo.
pause
