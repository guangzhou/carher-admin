#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "升级 cr-g:同步模型菜单(加新名 / 摘掉已下架的名字)+ 重打 Cursor 补丁 + 更新小代理。"
echo "不会问你要 Key —— 你之前配过的 Key 原样保留。"
echo "（Cursor 必须先完全退出：Cmd+Q）"
echo ""
sh "$DIR/cursor_team_setup.sh" --upgrade
echo ""
printf "按回车键关闭本窗口…"; read _
