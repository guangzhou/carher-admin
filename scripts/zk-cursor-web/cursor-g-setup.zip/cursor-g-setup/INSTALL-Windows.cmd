@echo off
setlocal
call "%~dp0cursor_team_setup.cmd" --apply
echo.
pause
