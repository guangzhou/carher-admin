cursor-g 一键安装(零依赖,不用装 Python / Node)

准备:
  1) 先拿到你的 API Key(找管理员,或用飞书「个人账户」表查)。
  2) 完全退出 Cursor(Mac 按 Cmd+Q;Windows 右键任务栏图标→退出。只关窗口不算)。

安装:
  Mac     :双击 INSTALL-Mac.command
           (若提示"无法打开、来自身份不明的开发者",右键该文件→打开→再点"打开")
  Windows :双击 INSTALL-Windows.cmd
           (若弹安全提示,选"仍要运行")

看到"完成"就装好了。最后一步在 Cursor 里:
  设置 → Models → OpenAI API Key,粘贴你的 key,点 Verify。
  然后模型菜单里选 cursor-g-5.6-sol 即可用。

出问题看飞书文档的"常见问题",或找管理员。
