@echo off
setlocal
rem Upgrade: sync menu + re-patch. Does not ask for the key. Quit Cursor first (tray icon - Quit).
call "%~dp0cursor_team_setup.cmd" --upgrade
echo.
pause
