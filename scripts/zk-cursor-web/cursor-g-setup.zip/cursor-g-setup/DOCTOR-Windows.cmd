@echo off
setlocal
rem Self-check, read-only. Send the whole screen to the admin.
call "%~dp0cursor_team_setup.cmd" --doctor
echo.
pause
