#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "让「Cursor 连远程服务器」的窗口里也能用 cr-g 的模型。"
echo ""
echo "为什么需要这一步:装完之后你的模型地址是 127.0.0.1:8788(你自己这台电脑上的小代理),"
echo "而远程窗口里的 127.0.0.1 指的是**远端那台服务器**,那边没有这个东西 ⇒ 模型全连不上。"
echo "这个脚本把远端的这个地址转回你本机。Cursor 里一个设置都不用改。"
echo ""
sh "$DIR/cursor_remote_ssh.sh"
echo ""
printf "要配哪台?(照着上面的名字填,或 用户名@IP;直接回车=退出): "
read HOSTNAME_IN
if [ -z "$HOSTNAME_IN" ]; then
  echo "已退出,什么都没动。"
  printf "按回车键关闭本窗口…"; read _; exit 0
fi
echo ""
echo "===== 先预演一遍,只显示要往 ssh 配置里加什么,不落盘 ====="
sh "$DIR/cursor_remote_ssh.sh" --host "$HOSTNAME_IN"
echo ""
printf "确认执行?输入 yes 回车(其它任何输入=取消): "
read ans
if [ "$ans" = "yes" ]; then
  sh "$DIR/cursor_remote_ssh.sh" --host "$HOSTNAME_IN" --apply
else
  echo "已取消,什么都没动。"
fi
echo ""
printf "按回车键关闭本窗口…"; read _
