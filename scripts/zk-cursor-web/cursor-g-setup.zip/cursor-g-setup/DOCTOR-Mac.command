#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "自检(只读,不会改任何东西)。把下面整屏发给管理员即可。"
echo ""
sh "$DIR/cursor_team_setup.sh" --doctor
echo ""
printf "按回车键关闭本窗口…"; read _
