#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
sh "$DIR/cursor_remote_ssh.sh" --wizard
echo ""
printf "按回车键关闭本窗口…"; read _
