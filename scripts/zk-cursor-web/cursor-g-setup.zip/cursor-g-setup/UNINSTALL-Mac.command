#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
echo "把 Cursor 恢复成装 cr-g 之前的样子。"
echo "（Cursor 必须先完全退出：Cmd+Q）"
echo ""
echo "===== 先预演一遍,只显示要动什么,不落盘 ====="
sh "$DIR/cursor_team_setup.sh" --uninstall
echo ""
printf "确认执行?输入 yes 回车(其它任何输入=取消): "
read ans
if [ "$ans" = "yes" ]; then
  sh "$DIR/cursor_team_setup.sh" --uninstall --apply
else
  echo "已取消,什么都没动。"
fi
echo ""
printf "按回车键关闭本窗口…"; read _
