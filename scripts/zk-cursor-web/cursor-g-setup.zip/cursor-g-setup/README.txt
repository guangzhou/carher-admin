cursor-g 一键安装(零依赖,不用装 Python / Node)

准备:
  1) 先拿到你的 API Key(找管理员,或用飞书「个人账户」表查)。
  2) 完全退出 Cursor(Mac 按 Cmd+Q;Windows 右键任务栏图标→退出。只关窗口不算)。

安装:
  Mac     :双击 INSTALL-Mac.command
           (若提示"无法打开、来自身份不明的开发者",右键该文件→打开→再点"打开")
  Windows :双击 INSTALL-Windows.cmd
           (若弹安全提示,选"仍要运行")

  安装过程中窗口会让你「粘贴 API Key 后回车」——粘一次就好,脚本自动写进去。
  (Windows 上若自动写 Key 跳过了,按提示在 Cursor 设置里手动粘一次即可。)

看到"完成"就装好了:启动 Cursor,模型菜单默认就是 cursor-g-5.6-sol,直接用。

Cursor 升级后 cursor-g 不见了怎么办?
  不用回滚升级。双击 REPAIR-Mac.command(Windows: REPAIR-Windows.cmd)一键修复,
  重启 Cursor 即可。你的 Key 和配置都还在,修复只重打补丁。

出问题看飞书文档的"常见问题",或找管理员。
