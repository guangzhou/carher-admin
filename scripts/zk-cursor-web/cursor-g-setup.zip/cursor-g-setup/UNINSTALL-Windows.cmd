@echo off
setlocal
rem Uninstall: dry-run first, then type yes. Quit Cursor first (tray icon - Quit).
call "%~dp0cursor_team_setup.cmd" --uninstall
echo.
set /p ans=Type yes and press Enter to really uninstall (anything else = cancel): 
if /i "%ans%"=="yes" (
  call "%~dp0cursor_team_setup.cmd" --uninstall --apply
) else (
  echo Cancelled. Nothing changed.
)
echo.
pause
