@echo off
chcp 65001 >nul
echo 把 Cursor 恢复成装 cr-g 之前的样子。
echo （Cursor 必须先完全退出：右键托盘图标 Quit）
echo.
echo ===== 先预演一遍,只显示要动什么,不落盘 =====
call "%~dp0cursor_team_setup.cmd" --uninstall
echo.
set /p ans=确认执行?输入 yes 回车(其它任何输入=取消):
if /i "%ans%"=="yes" (
  call "%~dp0cursor_team_setup.cmd" --uninstall --apply
) else (
  echo 已取消,什么都没动。
)
echo.
pause
