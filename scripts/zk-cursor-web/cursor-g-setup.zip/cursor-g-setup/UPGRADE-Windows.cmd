@echo off
chcp 65001 >nul
echo 升级 cr-g:同步模型菜单(加新名 / 摘掉已下架的名字)+ 重打 Cursor 补丁。
echo 不会问你要 Key —— 你之前配过的 Key 原样保留。
echo （Cursor 必须先完全退出：右键托盘图标 Quit）
echo.
call "%~dp0cursor_team_setup.cmd" --upgrade
echo.
pause
