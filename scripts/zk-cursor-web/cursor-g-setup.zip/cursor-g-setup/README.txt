cr-g 一键安装(零依赖,不用装 Python / Node)

━━━ 已经装过的同事:双击 UPGRADE(不是 INSTALL,也不是 REPAIR)━━━
  Mac     :双击 UPGRADE-Mac.command
  Windows :双击 UPGRADE-Windows.cmd
  它**不会问你要 Key** —— 你之前配过的 Key 原样保留(一个字节都不动)。要先完全退出 Cursor(Cmd+Q)。
  做四件事:
  1) 模型菜单**整份换成**下面那份清单(不是"缺的补上":清单之外的名字会被清掉)
  2) 所以你自己手工加过的第三方模型名(以及历史上装过的旧名)会一起被清掉。
     ⚠️ 这一步是**破坏性**的,所以动手之前脚本会先把你旧的那份清单备份到
        ~/.cursor-team-setup-backup/<版本>-<时间>-preconfig/applicationUser.blob.json
        (备份写不下去就直接中止,不会带着"没有退路"改你的库)。
        窗口里会**逐个列出**加了哪些、删了哪些,你可以对着看。
        想整份还回去:双击 UNINSTALL,或找管理员用 `--revert` 从那个备份恢复。
     如果你某个功能位(Chat / Cmd-K / Deep Search…)正好钉着一个被清掉的名字,
     会自动改回 grok-4.7 —— 否则菜单里找不到它,你也没法自己换回来。
  3) 重打 Cursor 界面补丁(等于 REPAIR 那一步)。**本次(09-22)新增一条**:
     修掉「上下文百分比显示成 8146%、每问一句都在压缩历史」那个毛病。
     原因是 Cursor 服务端从 9 月 20 号前后开始,把上下文窗口大小回成了"500"这种
     档位数字而不是真实的 500000,小了 1000 倍,于是 Cursor 认为你永远超限、每轮都要
     压缩。**所有模型都中,不是某一个模型的问题**,也不是你 Key 或设置的问题。
     补丁把这个数字还原成真实值:该压的时候(用到 90%)照样压,没到就不压。
     **本次(09-23)再新增一条**:修掉「发消息报 An unexpected error occurred /
     Request ID: xxxx」以及「This model does not support custom API keys」那两个报错。
     原因是 Cursor 最近给部分账号灰度开了一个"本地轮次"开关,开着的机器会把你的
     请求交给 **Cursor 自家的推理服务**,而那个服务不认我们的 Key(也不支持自定义 Key),
     于是必然报错 —— 跟你的 Key、网络、选哪个模型都无关,纯看你这台有没有被灰度到。
     补丁把这个开关对我们的模型关掉,请求回到原来那条能用的路上。
  3b) Windows 上光跑 REPAIR 不够,要跑 **UPGRADE**:REPAIR 按设计不碰配置/开关,
     而上面那个病有一半在"BYOK 开关被翻成了关",只有 UPGRADE/INSTALL 会把它写回来。
  4) 更新省流量的小代理(REPAIR 不做这一步)
  你的 Key、聊天记录、编辑器设置一个字节不动 —— 换的只有"模型菜单"这一份清单。

  三个按钮的区别,一句话:
    INSTALL = 第一次装(会问 Key)   UPGRADE = 已装过要更新(不问 Key)
    REPAIR  = Cursor 升级后模型没了,只重打补丁(不改菜单、不更新小代理)

  ★ 报错了先双击 DOCTOR(Mac: DOCTOR-Mac.command / Windows: DOCTOR-Windows.cmd)
    它**只读**,一个字节都不改。跑完把整屏(或它提示的那个 txt)发给管理员 ——
    里面是判断问题所必需的那几个值(补丁装没装 / 开关 / 地址 / Key 在不在 /
    报错那一发选的哪个模型)。**没有明文 Key**,只有长度和指纹前 16 位。
    截图看不到这些值,所以有 DOCTOR 就别只发截图,能省掉好几轮来回。

准备:
  1) 先拿到你的 API Key(找管理员,或用飞书「个人账户」表查)。
  2) 完全退出 Cursor(Mac 按 Cmd+Q;Windows 右键任务栏图标→退出。只关窗口不算)。

安装:
  Mac     :双击 INSTALL-Mac.command
           (若提示"无法打开、来自身份不明的开发者",右键该文件→打开→再点"打开")
  Windows :双击 INSTALL-Windows.cmd
           (若弹安全提示,选"仍要运行")

  安装过程中窗口会让你「粘贴 API Key 后回车」——粘一次就好,脚本自动写进去。
  (Windows 上若自动写 Key 跳过了,按提示在 Cursor 设置里手动粘一次即可。)

看到"完成"就装好了:启动 Cursor,模型菜单默认就是 grok-4.7,直接用。

模型清单(本版会把你的菜单**整份换成**这份,顺序就是你在菜单里看到的顺序)
  - grok-4.7
  - grok-4.6
  - grok-4.6-latest
  - grok-4.5-latest
  - grok-4.5
  - grok-4.20
  - grok-4.20-0309-reasoning
  - composer-2.5-fast
  - composer-2.5
  - gpt-5.6-sol
  - gpt-5.6-luna
  - gpt-5.6-terra
  - gpt-5.5
  - gpt-6-astra
  - gpt-6-luna
  - gpt-6-sol
  - gpt-6.1-sol
  - gpt-5.2
  - gpt-5.4
  - claude-opus-5-5
  - claude-sonnet-5-5
  - claude-haiku-4-5
  - claude-opus-5
  - claude-sonnet-5
  - codex-auto-review
  - deepseek-v4-flash
  - kimi-k2.7-code
  - glm-5.3-flash
  - qwen3-coder-next
  - jev
  已下架:cr-g-5.6-pro, sa-grok-imagine, cr-g-5.6, cr-g-5.6-instant, cr-g-5.6-mini, cr-g-5.6-t-mini, cr-g-research, cr-g-5.6-thinking, cr-g-5.6-luna, cr-g-5.6-thinking-min, cr-g-5.6-thinking-high, cr-g-5.6-thinking-max, cr-g-5.6-luna-min, cr-g-5.6-luna-high, cr-g-5.6-luna-max —— 装过旧版的机器上,UPGRADE 会自动摘掉。
  注:sa-grok-imagine 已从菜单去掉。它是**出图专用**,在 Cursor 的聊天线型上直接
     报错(实测 400 invalid_request_error),留在菜单里只会让人点了报错。
  注:cr-g 那一段(cr-g-5.6 / -instant / -mini / -t-mini / cr-g-research / -thinking / -luna
     以及 6 个 thinking/luna 档位变体)2026-10-12 已整段下架,菜单里不再有。
     装过旧版的机器双击 UPGRADE 会自动摘掉;要是某个功能位正钉着它们,会自动改回默认模型。
  注:claude 那 5 个名字要写全名(claude-opus-5-5 这种),没有 opus-5.5 这样的短名
     —— 短名在网关上不存在,点了就报错。

关于"增量传输"(装完自动开着,Mac 才有)
  装完之后你的 Cursor 不再直接连公网,而是先连本机一个小程序(127.0.0.1:8788),
  由它只把**这一轮新增的那几条消息**发出去,机房那边补回完整的对话再交给模型。
  - 模型看到的内容一个字都没变,回答质量不受影响。省的是你这边上传的流量:
    实测长对话省 86%,对话越长省得越多。
  - 那个小程序用 Cursor 自带的运行时跑,你不用装任何东西。
  - 它**不会**把你的对话内容存到你的磁盘上。
  - 机房那边万一挂了,它自动退回直连,你不会有感觉。它自己万一挂了,系统会自动拉起来。
  - 想看省了多少:浏览器打开 http://127.0.0.1:8788/metrics.json
  - 不想用了:双击 TURN-OFF-DELTA-Mac.command(要先退出 Cursor),立刻退回直连公网。

要用 Cursor 连远程服务器改代码?(左下角那个绿色按钮)
  症状:本地窗口好好的,一连上远程服务器,模型全报连不上 / Connection error。
  原因:上面那个小代理跑在**你自己这台电脑**上(127.0.0.1:8788)。远程窗口里的
       127.0.0.1 指的是**远端那台服务器**,它那边没有这个东西,所以必然连不上。
  一键解决:双击 REMOTE-SSH-Mac.command(Windows: REMOTE-SSH-Windows.cmd)
       它会列出你 ssh 里已有的服务器,你挑一台,**先预演给你看要加什么**,
       你输入 yes 才真的改。改的只有一行,加在 ~/.ssh/config 里:
           RemoteForward 8788 127.0.0.1:8788
       作用是:你 ssh 连过去的时候,顺手把远端的 8788 转回你本机的 8788。
       这样两边的地址都成立 —— **Cursor 里一个设置都不用改**,你的 Key 也始终
       只待在自己电脑上(不会落到那台服务器上,那种机器通常是多人共用的)。
  改完:完全退出 Cursor(Cmd+Q)重开,再连远程,发一条消息试试。
  撤掉:同一个按钮里没有撤销;要撤跑 `sh cursor_remote_ssh.sh --host <那台> --remove --apply`,
       或直接还原它给你留的备份 ~/.ssh/config.bak-<时间戳>(它写之前一定先备份)。
  两个常见误会:
   · 连第二个窗口时 ssh 可能提示 "remote port forwarding failed for listen port 8788"
     —— **无害,别去修**。那是第一个窗口已经占着了,模型照样能用。
   · 如果你的模型地址不是 127.0.0.1(比如 Windows 上就是直连公网),
     脚本会当场告诉你"不需要做这件事",然后一个字都不改。

发消息报 "Cannot convert argument to a ByteString ... value of 8203" 怎么办?
  完整报错长这样(数字可能不一样):
    Local agent request failed
    Cannot convert argument to a ByteString because the character at index 32
    has a value of 8203 which is greater than 255.
  原因:你粘进去的那把 Key 里混进了**一个看不见的字符**(零宽空格之类),多半是从
       飞书表格 / 聊天窗口 / 网页里复制时顺带带进来的。Key 看起来一模一样、长度
       肉眼也数不出差别,但 Cursor 拼请求头时装不下它,当场就报错。
  两个判断要点,省得你白折腾:
   · 这个错是**你这台电脑本地**报的 —— 请求一个字节都没发出去。所以跟网络、
     跟我们机房、跟模型、跟你选哪个模型统统无关,换模型换网络都不会好。
   · 报错里那个 index 减 7 就是它在 Key 里的位置("Bearer " 占 7 个字符)。
     上面那个 32 ⇒ 它躲在 Key 的第 26 个字符,也就是**紧贴在 Key 末尾**。
  怎么修(两种都行,不用重启 Cursor):
   · 双击 INSTALL,在"粘贴 API Key"那一步重新粘一次 —— 安装器现在会自动把这类
     字符剥掉,并在窗口里告诉你剥了几个、在第几位。
     (**别用 UPGRADE**:UPGRADE 按设计不问 Key、不碰 Key,治不了这个病。)
   · 或者在 Cursor 设置里把 Key 那一栏**全选删掉**(别只删末尾),重新粘一次。
     ⚠️ 重新粘的时候**别再从飞书表格/聊天里复制** —— 从表格里双击单元格进编辑态
        再复制,或者找管理员要一份纯文本。
  想先确认是不是这个病:双击 DOCTOR。它会把 Key 里不可见字符的**位置和码位**打出来
  (例如 "字符下标 25  U+200B  ZWSP 零宽空格"),**不会**打出你的 Key 内容。

Cursor 升级后 cr-g 的模型不见了怎么办?
  不用回滚升级。双击 REPAIR-Mac.command(Windows: REPAIR-Windows.cmd)一键修复,
  重启 Cursor 即可。你的 Key 和配置都还在,修复只重打补丁。

不想用了 / 要把 Cursor 恢复成装之前的样子
  先完全退出 Cursor(Mac: Cmd+Q;Windows: 右键托盘图标退出),然后
  Mac     :双击 UNINSTALL-Mac.command
  Windows :双击 UNINSTALL-Windows.cmd
  它会**先预演一遍**列出要动什么,你输入 yes 才真的执行。做四件事:
  1) 把 Cursor 的界面文件从备份还原(只用与当前 Cursor 同版本的备份 —— 版本不对它会
     拒绝,并让你用官方安装包覆盖安装一次,那样也能回原厂,聊天记录和设置不会丢)
  2) 关掉 BYOK(地址清空、开关关掉)、摘掉 cr-g 那些模型名,
     并把你装之前自己选的模型还回去(从备份里取,不是一律重置)
  3) 从钥匙串/库里删掉写进去的 API Key
  4) 卸掉本机小代理、去掉升级锁
  你自己加的第三方模型、你的聊天记录、你的编辑器设置都不动。
  备份目录(~/.cursor-team-setup-backup)也不删,想装回来再双击 INSTALL 就行。

出问题看飞书文档的"常见问题",或找管理员。
