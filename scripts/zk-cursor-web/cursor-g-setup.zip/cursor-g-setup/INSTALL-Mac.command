#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
sh "$DIR/cursor_team_setup.sh" --apply
echo ""
printf "按回车键关闭本窗口…"; read _
